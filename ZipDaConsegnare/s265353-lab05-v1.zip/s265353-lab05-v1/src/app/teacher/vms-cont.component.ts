import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vms-cont',
  templateUrl: './vms-cont.component.html',
  styleUrls: ['./vms-cont.component.css']
})
export class VmsContComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
