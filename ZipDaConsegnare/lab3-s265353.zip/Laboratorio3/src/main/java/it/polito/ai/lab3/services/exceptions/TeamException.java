package it.polito.ai.lab3.services.exceptions;

public class TeamException extends TeamServiceException {

    public TeamException(String errorMessage) {
        super(errorMessage);
    }
}
