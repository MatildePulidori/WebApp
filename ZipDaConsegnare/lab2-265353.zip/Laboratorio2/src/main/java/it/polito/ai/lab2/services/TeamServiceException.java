package it.polito.ai.lab2.services;

public class TeamServiceException extends RuntimeException {

    public TeamServiceException(String errorMessage){
        super(errorMessage);
    }

}
