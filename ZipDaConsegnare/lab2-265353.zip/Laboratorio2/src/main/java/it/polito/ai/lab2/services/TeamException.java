package it.polito.ai.lab2.services;

public class TeamException extends TeamServiceException {

    public TeamException(String errorMessage) {
        super(errorMessage);
    }
}
